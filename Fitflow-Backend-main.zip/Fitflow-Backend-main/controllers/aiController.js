// // controllers/aiController.js
// import genAI from "@google/generative-ai";

// // Initialize Gemini client
// const client = new genAI.Client({
//   apiKey: process.env.GOOGLE_API_KEY,
// });

// // Chat endpoint
// export const chatWithAI = async (req, res) => {
//   const { message } = req.body;

//   if (!message || message.trim() === "") {
//     return res.status(400).json({ reply: "Please enter a message." });
//   }

//   try {
//     const response = await client.models.generateContent({
//       model: "gemini-2.5-flash",
//       contents: [
//         { text: `Answer concisely (1–2 sentences) for a website chat: ${message}` }
//       ],
//       temperature: 0.5,      // focused & short responses
//       maxOutputTokens: 60,   // limits response length
//     });

//     const reply = response?.text || "Sorry, I didn't understand that.";

//     res.json({ reply });

//   } catch (error) {
//     console.error("Gemini API Error:", error);
//     res.status(500).json({ reply: "Server error. Please try again later." });
//   }
// };

import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
dotenv.config();

const client = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const chatWithAI = async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ reply: "No message provided" });

    const response = await client.models.generateContent({
      model: "gemini-2.5-flash",     // valid model with new SDK
      contents: [{ text: `Answer concisely: ${message}` }],
      temperature: 0.4,
      maxOutputTokens: 60
    });

    res.json({ reply: response.text });
  } catch (err) {
    console.error("Gemini Error:", err);
    res.status(500).json({ reply: "Server error, try again later." });
  }
};



// import { GoogleGenerativeAI } from "@google/generative-ai";
// import dotenv from "dotenv";

// dotenv.config();

// // Initialize Gemini client
// const client = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// export const chatWithAI = async (req, res) => {
//   try {
//     const { message } = req.body;
//     if (!message) return res.status(400).json({ reply: "No message provided" });

//     // Initialize the model
//     const model = client.getGenerativeModel({ model: "gemini-2.5-flash" });

//     // Pass prompt as array of objects
//     const response = await model.generateContent({
//       // format: [{ type: "text", text: "..." }]
//       prompt: [{ type: "text", text: message }],
//       temperature: 0.7,
//       maxOutputTokens: 500,
//     });

//     res.json({ reply: response.candidates[0].content });
//   } catch (err) {
//     console.error("Gemini API Error:", err);
//     res.status(500).json({ reply: "Server error, try again later." });
//   }
// };

// export const chatWithAI = async (req, res) => {
//   try {
//     const { message } = req.body;
//     if (!message) return res.status(400).json({ reply: "No message provided" });

//     // Use the correct model
//     const model = client.getGenerativeModel({ model: "gemini-2.5-flash" });

//     const response = await model.generateContent({
//       prompt: message,
//       temperature: 0.7,
//       maxOutputTokens: 500,
//     });

//     res.json({ reply: response.candidates[0].content });
//   } catch (err) {
//     console.error("Gemini API Error:", err);
//     res.status(500).json({ reply: "Server error, try again later." });
//   }
// };

// import dotenv from "dotenv";
// import { GoogleGenerativeAI } from "@google/generative-ai";
// dotenv.config();

// const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// export const chatWithAI = async (req, res) => {
//   try {
//     const { message } = req.body;

//     const model = genAI.getGenerativeModel({ model: "gemini-pro" });

//     const result = await model.generateContent(message);
//     const replyText = result.response.text();

//     res.json({ reply: replyText });

//   } catch (error) {
//     console.error("Gemini Error:", error);
//     res.status(500).json({ error: "AI chat failed" });
//   }
// };

// import dotenv from "dotenv";
// import { GoogleGenerativeAI } from "@google/generative-ai";
// dotenv.config();

// const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// export const chatWithAI = async (req, res) => {
//   try {
//     const { message } = req.body;

//     if (!message) {
//       return res.status(400).json({ error: "Message is required" });
//     }

//     // IMPORTANT: use a real existing model
//     const model = genAI.getGenerativeModel({
//       model: "gemini-1.5-flash-002",
//     });

//     const result = await model.generateContent(message);
//     const replyText = result.response.text();

//     res.json({ reply: replyText });

//   } catch (error) {
//     console.error("Gemini Error:", error);
//     res.status(500).json({ error: "AI chat failed" });
//   }
// };

// import dotenv from "dotenv";
// import { GoogleGenerativeAI } from "@google/generative-ai";
// dotenv.config();

// const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// export const chatWithAI = async (req, res) => {
//   try {
//     const { message } = req.body;

//     if (!message) {
//       return res.status(400).json({ error: "Message is required" });
//     }

//     // Use a valid model (gemini-pro is removed!!)
//     const model = genAI.getGenerativeModel({
//       model: "gemini-1.5-flash", // FAST + CHEAP + WORKS
//     });

//     const result = await model.generateContent(message);

//     const replyText = result.response.text();
//     res.json({ reply: replyText });

//   } catch (error) {
//     console.error("Gemini Error:", error);
//     res.status(500).json({ error: "AI Chat failed" });
//   }
// };
