import mongoose from "mongoose";

const commentSchema = new mongoose.Schema({
  text: String,
  user: String,
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const questionSchema = new mongoose.Schema({
  text: {
    type: String,
    required: true,
  },
  user: String,
  comments: [commentSchema],
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Question = mongoose.model("Question", questionSchema);

export default Question;


// import mongoose from "mongoose";

// const questionSchema = new mongoose.Schema({
//   id: String,
//   text: String,
//   user: String,
//   likes: Number,
//   comments: [
//     {
//       id: String,
//       text: String,
//       user: String,
//     },
//   ],
// });

// const Question = mongoose.model("Question", questionSchema);

// export default Question;